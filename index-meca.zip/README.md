## How to update

1. Render `index.qmd`:
```
$ quarto render
```

2. Publish document
```
$ quarto publish gh-pages
```
